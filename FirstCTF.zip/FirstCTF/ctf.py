#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Oct 25 17:57:16 2023

@author: 0xNashi
"""

from flask import Flask, request, render_template, redirect,url_for,render_template_string
import jwt 
from jinja2 import Template
import os


app = Flask(__name__,template_folder='.')
secret = ''


users = {
    1: {'id':1,'user':'boss','hack':'{{ config }}'},
    2: {'id':2,'user':'admin','hack':""},
    3: {'id':3,'user':'normal_user','hack':""}
}


sstihtml="""
<html>
<head>
    <title>{{7 * 7 }} = 49?</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        header {
            background-color: #333;
            color: #fff;
            padding: 20px;
            text-align: center;
        }
        h1 {
            font-size: 24px;
        }
        .container {
            max-width: 1800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 5px;
            height: 8000px;
        }
    </style>
</head>
<body>
    <header>
        <h1>Is 7 * 7 equal to 49?</h1>
    </header>
    <div class="container">
        <h1 style="color:red;">Try Find Flag.txt</h1>
        <h2>Token: {{ jwt_token }}</h2>
        <h2>Hack: %s</h2>
    </div>
    
    <div style="text-align:center;">
        <h5>This CTF is provided by 0xnashi</h5>
    </div>
</body>
</html>"""


def generate_jwt(user_id, role):
    payload = {'user_id': user_id, 'role': role,'hack':""}
    token = jwt.encode(payload, secret, algorithm='HS256')
    return token

def parse_jwt(token,secret):
    try:
        payload = jwt.decode(token, secret, algorithms='HS256')
        return payload
    except:
        return 'Cannot Parse Your Input'



@app.route('/')
def index():
    
    return render_template('login.html')


@app.route('/validate', methods=['POST'])
def validate():
    notification_message = "JWT Validation Failed"
    jwt_token = request.form['jwt']
    
    try:
        data = parse_jwt(jwt_token,secret)
        if data !='Cannot Parse Your Input':
            user_id = data['user_id']
            role = data['role']
    
            if user_id == 1 and role == 'boss':
                return redirect(url_for('boss', data=data))
            elif user_id == 2 and role == 'admin':
                return redirect(url_for('admin', data=data))
        else:
            return  render_template('login.html', notification_message=notification_message)
    except:
            return  render_template('login.html', notification_message=notification_message)



@app.route('/boss')
def boss():
    notification_message = "JWT Validation Failed"
    notification_message1 = "U R NOT BOSS!!"
    jwt_token = request.args.get('data')
    data = eval(jwt_token)
    ans = data['hack']
    
    if data:
        user_id = data['user_id']
        role = data['role']


        if user_id == 1 and role == 'boss':
            try:
                return render_template_string(sstihtml%ans,jwt_token=jwt_token)
            except:
                return render_template('login.html')
            
        return render_template('login.html',notification_message=notification_message1)
            
    return render_template('login.html', notification_message=notification_message)
 

@app.route('/admin')
def admin():
    jwt_token = request.args.get('data')
    data = eval(jwt_token)
    notification_message1 = "U R NOT ADMIN!!"
    notification_message = "JWT Validation Failed"
    
    if data:
        user_id = data['user_id']
        role = data['role']


        if user_id == 2 and role == 'admin':  
            return render_template('admin.html')
    
        return render_template('login.html',notification_message=notification_message1)
    return render_template('login.html', notification_message=notification_message)


@app.route('/login_failed')
def login_failed():
    return "Login Failed"


if __name__ == '__main__':
    app.run(debug=False)



